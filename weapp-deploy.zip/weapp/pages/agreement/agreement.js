Page({
  data: {},
  onLoad() {},
})
