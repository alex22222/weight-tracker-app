# 体重追踪小程序 - 生产部署包

## 📦 包内容说明

```
deploy-package/
├── backend/              # Next.js 后端服务
│   ├── src/             # 源代码
│   ├── prisma/          # 数据库 schema
│   ├── package.json     # 依赖配置
│   ├── next.config.js   # Next.js 配置
│   └── .env.production.example  # 环境变量模板
├── weapp/               # 微信小程序代码
│   ├── pages/           # 页面
│   ├── components/      # 组件
│   ├── config.js        # API 配置
│   └── app.js           # 入口
├── scripts/             # 部署脚本
├── docs/                # 部署文档
│   ├── DEPLOY.md        # 完整部署指南
│   ├── DEPLOY_CHECKLIST.md  # 部署检查清单
│   ├── CLOUDBASE_SETUP.md   # CloudBase 设置
│   └── database-rules.md    # 数据库安全规则
├── cloudbase.json       # CloudBase CLI 配置
└── README.md            # 本文件
```

## 🚀 快速开始

### 方式一：腾讯云 CloudBase CloudRun（推荐）

#### 1. 准备工作
```bash
# 安装 CloudBase CLI
npm install -g @cloudbase/cli

# 登录腾讯云
tcb login
```

#### 2. 创建 CloudBase 环境
- 访问 [CloudBase 控制台](https://console.cloud.tencent.com/tcb)
- 创建新环境（选择免费版或按量付费）
- 记录环境 ID

#### 3. 创建数据库集合
在 CloudBase 控制台创建以下集合：
1. `users` - 用户数据
2. `user_settings` - 用户设置
3. `weight_entries` - 体重记录
4. `reading_entries` - 读书记录
5. `goals` - 目标数据
6. `messages` - 消息通知
7. `friends` - 好友关系
8. `tasks` - 打卡任务
9. `task_members` - 任务成员
10. `task_check_ins` - 任务打卡

#### 4. 配置环境变量
```bash
cd backend
cp .env.production.example .env.production
# 编辑 .env.production 填写实际值
```

#### 5. 部署后端
```bash
# 在 backend 目录下
npm install
npm run build

# 使用 CloudBase CLI 部署
tcb cloudrun:deploy --envId <你的环境ID>
```

#### 6. 配置小程序
```bash
cd ../weapp
# 编辑 config.js 文件，更新 apiBaseUrl
```

#### 7. 部署小程序
使用微信开发者工具打开 `weapp` 文件夹，上传代码到微信小程序后台。

### 方式二：Docker 部署

```bash
cd backend
docker build -t weight-tracker-app .
docker run -p 3000:3000 --env-file .env.production weight-tracker-app
```

## ⚙️ 环境变量配置

### 必需变量
```env
# CloudBase 配置
CLOUDBASE_ENV_ID=your-env-id
CLOUDBASE_SECRET_ID=your-secret-id
CLOUDBASE_SECRET_KEY=your-secret-key

# 微信小程序配置
WECHAT_APPID=your-app-id
WECHAT_SECRET=your-app-secret

# JWT 密钥
JWT_SECRET=your-random-secret-key
```

## 📚 详细文档

- [部署指南](docs/DEPLOY.md) - 完整的部署步骤
- [检查清单](docs/DEPLOY_CHECKLIST.md) - 部署前检查
- [CloudBase 设置](docs/CLOUDBASE_SETUP.md) - CloudBase 详细配置
- [数据库规则](docs/database-rules.md) - 安全规则配置

## 🔧 技术栈

- **后端**: Next.js 14 + TypeScript + CloudBase SDK
- **小程序**: 微信小程序原生框架 + JavaScript
- **数据库**: CloudBase (MongoDB-like)
- **部署**: CloudBase CloudRun / Docker

## 📝 注意事项

1. **首次部署**需要创建数据库集合和配置安全规则
2. **生产环境**必须修改 JWT_SECRET 为随机字符串
3. **小程序**需要在微信公众平台配置服务器域名
4. **CloudBase** 免费版有资源限制，生产环境建议升级

## 🐛 常见问题

### 1. 后端部署失败
```bash
# 检查 CloudBase CLI 是否登录
tcb login

# 检查环境 ID 是否正确
tcb env:list
```

### 2. 小程序无法连接后端
- 检查 `weapp/config.js` 中的 `apiBaseUrl`
- 确认后端服务已启动
- 检查小程序服务器域名白名单

### 3. 数据库连接失败
- 确认已创建所有集合
- 检查安全规则配置
- 验证 CloudBase 环境变量

## 📞 支持

遇到问题请查看 `docs/` 目录下的详细文档，或联系开发团队。

---
**版本**: v3.2  
**构建时间**: 2025-04-05  
**适用环境**: 腾讯云 CloudBase / Docker
