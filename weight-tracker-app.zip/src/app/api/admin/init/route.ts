import { NextResponse } from 'next/server'
import { adapter } from '../../../../lib/db-adapter'
import { hashPassword } from '../../../../lib/auth'

// POST /api/admin/init - 初始化 admin 用户
export async function POST() {
  try {
    // 检查 admin 用户是否已存在
    let admin = await adapter.findUserByUsername('admin')

    if (!admin) {
      // 创建 admin 用户
      const hashedPassword = hashPassword('123123')
      admin = await adapter.createUser({
        username: 'admin',
        password: hashedPassword,
        gender: 'male',
      })
      
      // 创建 admin 设置
      if (admin.id) {
        await adapter.createUserSettings({
          userId: admin.id,
          height: 170,
          targetWeight: 65,
        })
      }
      
      return NextResponse.json({ message: 'Admin user created', admin: { id: admin.id, username: admin.username } })
    }

    return NextResponse.json({ message: 'Admin user already exists', admin: { id: admin.id, username: admin.username } })
  } catch (error) {
    console.error('Error initializing admin:', error)
    return NextResponse.json({ error: 'Failed to initialize admin' }, { status: 500 })
  }
}
